# Decision Journal

Structured log of meaningful decisions with reasoning, alternatives considered, and outcome tracking. Based on Architecture Decision Record (ADR) methodology.

## Purpose

Memory without reflection is just storage. This journal captures the *reasoning* behind choices, not just the choices themselves. Over time, it reveals:
- Which decision-making patterns lead to good outcomes
- When high-confidence decisions fail (overconfidence signal)
- When forced-alternative exploration produces better results
- Decision chains that can be traced via `Supersedes` links

## When to Log a Decision

Log when ANY of these apply:
- Choosing between 2+ viable approaches for implementation
- Making an architectural or structural choice (file layout, data model, API design)
- Selecting a tool, service, or integration over alternatives
- Changing a previously established pattern or convention
- Making a trade-off (speed vs quality, simplicity vs flexibility, etc.)

Do NOT log:
- Routine task execution with no real alternatives
- Obvious fixes (typos, broken imports)
- Decisions already captured in git commit messages with sufficient context

## Decision Entry Format

Use the template in `TEMPLATE.md`. Key fields:

| Field | Purpose |
|-------|---------|
| **ID** | `D-YYYY-MM-DD-NN` (sequential per day) |
| **Status** | `proposed` → `accepted` → `superseded` or `deprecated` |
| **Context** | What situation prompted this decision |
| **Alternatives** | Minimum 2 alternatives considered (aim for 3+) |
| **Decision** | What was chosen and why |
| **Consequences** | Expected positive and negative outcomes |
| **Supersedes** | Link to prior decision this replaces (traceable chain) |
| **Outcome** | Revisited later: did it work? What happened? |

## Decision Index

<!-- Newest first. Update when adding/superseding decisions. -->

| ID | Date | Title | Status | Domain |
|----|------|-------|--------|--------|
| D-2026-05-09-01 | 2026-05-09 | ZenMux usage monitoring via local skill and hourly agent | accepted | integrations |

## Quality Signal: The 3-Alternative Rule

Decisions where 3+ alternatives were seriously considered before choosing tend to be right ~80% of the time. Decisions made with high initial confidence have the worst hit rate. When logging, force yourself to articulate at least 2 real alternatives, even if one seems obviously better.

## Reviewing Decisions

Monthly review checklist:
1. Check decisions older than 30 days, fill in the `Outcome` field
2. Identify decisions that should be superseded based on new information
3. Look for patterns: which domains have the most superseded decisions?
4. Promote validated decision patterns to `knowledge/domains/` files

## Integration with Other Systems

- **Mengram**: Store decision summaries for cross-session recall
- **Knowledge Domains**: Validated decision patterns get promoted to domain files
- **Hypotheses**: Decisions about experiments link to `hypotheses/active/`
- **Mistakes Log**: Failed decisions should cross-reference `Mistakes_Learning_Log.md`
