# Recent Insights (Last 30 Days)

Distilled learnings that haven't yet been formalized into domain knowledge.

<!-- Update this file weekly, move old entries to domain knowledge when validated -->

## 2026-03-18: Self-Improving System Architecture

From [Product Compass article](https://www.productcompass.pm/p/self-improving-claude-system):

**Key insight**: Progressive disclosure via file-based knowledge graph reduces context window pressure while enabling accumulated expertise.

**Implementation**:
- Created `knowledge/INDEX.md` as router
- Domain-specific knowledge in `domains/`
- Active hypotheses in `hypotheses/active/`
- False beliefs catalog for disproven assumptions

**Expected outcome**: More targeted expertise, less context waste, compounding improvement over time.

---

## 2026-04-04: Three Compounding Knowledge Systems (from Huryn article)

From [Claude.md Snippets article](https://open.substack.com/pub/huryn/p/claude-md-snippets):

**Key insight**: Memory without reflection is just storage. Three systems compound together: (1) Decision Journal captures reasoning behind choices with ADR-style entries and forced-alternative exploration, (2) Active per-task knowledge retrieval prevents stale context mid-session, (3) Quality gates with concrete rubrics prevent the "agent praises its own mediocre work" problem.

**Implementation**: Created `knowledge/decisions/`, `knowledge/quality-gates/`, and three new rules (Decision Journal Protocol, Mid-Session Knowledge Retrieval, Quality Gate Evaluation). Updated INDEX.md with pre-task checklist.

**Expected outcome**: Better decision-making via forced alternatives, fewer missed patterns via per-task retrieval, higher output quality via rubric-based self-evaluation. The 3-alternative rule alone should improve decision quality measurably.

**Status**: Raw - will validate over next 30 days

---

## 2026-04-08: VoiceOS MCP Server Build Lessons

From building zo-voiceos-bridge.

**Key insights**:
1. VoiceOS file picker only accepts `.py`, `.sh`, `.ts`, `.js` — not `.cmd` or `.bat`. Use launch command instead.
2. On Windows 11, `python` often missing from PATH but `py` always works. Use `py` in launch commands.
3. FastMCP (`pip install mcp`) is the right way to build VoiceOS MCP servers — far simpler than hand-rolling JSON-RPC.
4. VoiceOS stdio transport expects the script to persist and handle multiple JSON-RPC messages over stdin/stdout. Scripts that read one line and exit will fail with "Connection closed."
5. `.env` files for secrets should be gitignored with restricted permissions (600).

**Implication**: Future VoiceOS integrations should default to Python + FastMCP, use `py` on Windows, and ensure the script uses the library's built-in event loop rather than manual stdio handling.

**Status**: Raw

---

## Template for New Insight

```markdown
## YYYY-MM-DD: [Short description]

[Context - what happened, what was observed]

**Key insight**: [The distilled learning]

**Implication**: [How this changes how we approach similar situations]

**Status**: [Raw | Validating | Ready for domain]
```

## How to Process Insights

1. **Add** new insights here as they occur
2. **Review** weekly - which insights have proven themselves?
3. **Promote** validated insights to domain knowledge files
4. **Archive** invalidated insights (or move to false-beliefs)
